export enum PaymentMethod {
  CREDIT_CARD = "CREDIT_CARD",
  COUPON = "COUPON",
}
