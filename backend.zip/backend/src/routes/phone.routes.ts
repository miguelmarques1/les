import * as express from "express";

const Router = express.Router();

export { Router as phoneRouter };