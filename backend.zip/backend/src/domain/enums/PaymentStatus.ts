export enum PaymentStatus {
    APPROVED = 'APPROVED',
    DENIED = 'DENIED', 
}