export enum ResidenceType {
    HOUSE = "HOUSE", 
    APARTMENT = "APARTMENT",
  }