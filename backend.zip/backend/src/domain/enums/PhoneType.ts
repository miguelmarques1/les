export enum PhoneType {
    LANDLINE = "LANDLINE", 
    MOBILE = "MOBILE",
  }