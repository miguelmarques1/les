export enum ReturnExchangeType {
    RETURN = "RETURN",
    EXCHANGE = "EXCHANGE"
}