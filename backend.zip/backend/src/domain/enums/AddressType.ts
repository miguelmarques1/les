export enum AddressType {
    BILLING = "BILLING",
    SHIPPING = "SHIPPING"
}