export enum StockBookStatus {
    AVAILABLE = "AVAILABLE", 
    SOLD = "SOLD",
    BLOCKED = 'BLOCKED',
}