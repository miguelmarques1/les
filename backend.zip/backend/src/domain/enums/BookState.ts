export enum BookState {
    ACTIVE = 'ACTIVE',
    INACTIVE = 'INACTIVE'
}