export enum CouponStatus {
    AVAILABLE = 'AVAILABLE',
    EXPIRED = 'EXPIRED',
    USED = 'USED'
}