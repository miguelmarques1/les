export enum CouponType {
    PERCENTAGE = 'PERCENTAGE',
    VALUE = 'VALUE'
}