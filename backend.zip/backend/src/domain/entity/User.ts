
@Entity()
export class User {}