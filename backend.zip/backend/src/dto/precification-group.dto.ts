export class PrecificationGroupOutputDTO {
    public constructor(
        public id: number,
        public name: string,
        public profit_percentage: number,
    ) {}
}