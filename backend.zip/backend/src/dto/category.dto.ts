export class CategoryOutputDTO {
    public constructor(
        public id: number,
        public name: string,
    ) { }
}